package com.datamatics.claimapp;

  import org.junit.jupiter.api.Test; import
  org.springframework.boot.test.context.SpringBootTest;
  
  @SpringBootTest class ClaimappApplicationTests {
  
  @Test void contextLoads() { }
  
  }
 