package com.datamatics.claimapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.datamatics.claimapp.models.Customer;
import com.datamatics.claimapp.services.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
	{
		return this.customerService.saveCustomer(customer);
	}
	@CrossOrigin("*")
	@GetMapping("/getallcustomers")
	public List<Customer> getAllCustomers()
	{
		return this.customerService.getAllCustomers();
	}
	
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyId/{customerId}")
	public Customer getCustomerById(@PathVariable("customerId") long customerId)
	{
		return this.customerService.getCustomerById(customerId);
	}
}
