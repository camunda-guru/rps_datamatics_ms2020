package com.datamatics.claimapp.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="Vehicle")
@Getter
@Setter
public class Vehicle {
	@Id
	@Column(name="Chasis_No")
	private long chasisNo;
	@Column(name="Reg_No",length = 50,nullable = false)
	private String regNo;
	@Column(name="Color",length = 25,nullable = false)
	private String color;
	@DateTimeFormat(iso = ISO.DATE)
	@Column(name="DOR")
	private LocalDate dor;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="Customer_Id")
	private Customer customer;
	
	
}
