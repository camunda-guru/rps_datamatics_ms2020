package com.datamatics.claimapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datamatics.claimapp.models.Customer;
import com.datamatics.claimapp.repositories.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	
	//insert query
	
	public Customer saveCustomer(Customer customer)
	{
		return this.customerRepo.save(customer);
	}
	
	//findall
	public List<Customer> getAllCustomers()
	{
		return this.customerRepo.findAll();
	}
	
	//find by Id
	
	public Customer getCustomerById(long customerId)
	{
		return this.customerRepo.findById(customerId).orElse(null);
	}
	
	

}
