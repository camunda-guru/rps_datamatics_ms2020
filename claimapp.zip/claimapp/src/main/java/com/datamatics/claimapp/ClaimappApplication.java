package com.datamatics.claimapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimappApplication.class, args);
	}

}
