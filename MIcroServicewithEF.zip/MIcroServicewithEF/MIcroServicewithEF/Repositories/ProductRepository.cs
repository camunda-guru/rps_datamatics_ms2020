﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MIcroServicewithEF.EFContext;
using MIcroServicewithEF.Models;

namespace MIcroServicewithEF.Repositories
{
    public class ProductRepository : IDisposable,IProductRepository
    {
        DataContext _context;

        public ProductRepository(DataContext context)
        {
            _context = context;
        }
        public void DeleteProduct(int id)
        {
            throw new NotImplementedException();
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_context != null)
                {
                   _context.Dispose();
                   _context = null;
                }
            }
        }

        public void Dispose()
        {

            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Product> GetAllProducts()
        {
            return _context.Product;
        }

        public Product GetProduct(int id)
        {
            var query = from Product prod in _context.Product.ToList()
                        where prod.ProductId == id
                        select prod;
            return query.ToList<Product>().First();
        }

        public void SaveProduct(Product product)
        {
            throw new NotImplementedException();
        }

        public void UpdateProduct(Product product)
        {
            throw new NotImplementedException();
        }
    }
}
