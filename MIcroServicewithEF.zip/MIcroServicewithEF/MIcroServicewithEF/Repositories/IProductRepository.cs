﻿using MIcroServicewithEF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MIcroServicewithEF.Repositories
{
   public interface IProductRepository
    {
        void SaveProduct(Product product);
        IEnumerable<Product> GetAllProducts();
        Product GetProduct(int id);
        void DeleteProduct(int id);
        void UpdateProduct(Product product);
    }
}
