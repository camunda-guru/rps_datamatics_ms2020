﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MIcroServicewithEF.Models
{
    [Table("Product")]
    public class Product
    {
      
        public int ProductId { get; set; }
        [Required]
        [StringLength(60, MinimumLength = 4)]
        [Display(Name = "Full Name")]
        public String Name { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime DOP { get; set; }
    }
}
