﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MIcroServicewithEF.Models;
using MIcroServicewithEF.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MIcroServicewithEF.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductRepoController : ControllerBase
    {

        private IProductRepository productRepository;

        public ProductRepoController(IProductRepository obj)
        {
            productRepository = obj;
        }

        // GET api/values
        public IEnumerable<Product> Get()
        {
            return productRepository.GetAllProducts();
        }
        // GET api/values
        [HttpGet("{id}")]
        public Product Get([FromRoute] int id)
        {
            return productRepository.GetProduct(id);
        }



    }
}